import { Component, OnInit } from '@angular/core';
import { TodoService, Todo } from '../../services/todo.service';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html'
})
export class TodoListComponent implements OnInit {
  todos: Todo[] = [];
  newTodoTitle = '';

  constructor(private todoService: TodoService) {}

  ngOnInit() {
    this.loadTodos();
  }

  loadTodos() {
    this.todoService.getTodos().subscribe(t => this.todos = t);
  }

  addTodo() {
    if (!this.newTodoTitle.trim()) return;
    this.todoService.addTodo({ title: this.newTodoTitle, completed: false })
      .subscribe(() => {
        this.newTodoTitle = '';
        this.loadTodos();
      });
  }

  toggleComplete(todo: Todo) {
    this.todoService.updateTodo(todo).subscribe();
  }

  delete(id?: number) {
    if (id) this.todoService.deleteTodo(id).subscribe(() => this.loadTodos());
  }
}
