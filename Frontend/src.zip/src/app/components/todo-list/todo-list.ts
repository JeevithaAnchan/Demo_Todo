import { Component } from '@angular/core';

interface Todo {
  id: number;
  title: string;
  completed: boolean;
}

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.html',
  styleUrls: ['./todo-list.css']
})
export class TodoList {
  todos: Todo[] = [];
  newTodo: string = '';
  nextId: number = 1;

  addTodo() {
    if (this.newTodo.trim() === '') return;

    this.todos.push({
      id: this.nextId++,
      title: this.newTodo.trim(),
      completed: false
    });

    this.newTodo = '';
  }

  toggleComplete(todo: Todo) {
    todo.completed = !todo.completed;
  }

  deleteTodo(id: number) {
    this.todos = this.todos.filter(todo => todo.id !== id);
  }
}
